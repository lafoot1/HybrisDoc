/**
 * 
 */
package com.bazaarvoice.hybris.exception;

/**
 * @author christina
 * 
 */
public class BazaarvoiceProductFeedExportException extends RuntimeException
{

	public BazaarvoiceProductFeedExportException(final String message)
	{
		super(message);
	}



}
