/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 6, 2018 12:33:54 PM                     ---
 * ----------------------------------------------------------------
 */
package com.bazaarvoice.hybris.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedBazaarvoiceConstants
{
	public static final String EXTENSIONNAME = "bazaarvoice";
	public static class TC
	{
		public static final String BAZAARVOICECONFIG = "BazaarvoiceConfig".intern();
		public static final String BAZAARVOICEPRODUCTFEEDEXPORTCRONJOB = "BazaarvoiceProductFeedExportCronJob".intern();
		public static final String ENVIRONMENTTYPE = "environmentType".intern();
	}
	public static class Attributes
	{
		public static class CMSSite
		{
			public static final String BVCONFIG = "bvConfig".intern();
			public static final String BVLOCALE = "bvLocale".intern();
		}
	}
	public static class Enumerations
	{
		public static class EnvironmentType
		{
			public static final String STAGING = "Staging".intern();
			public static final String PRODUCTION = "Production".intern();
		}
	}
	
	protected GeneratedBazaarvoiceConstants()
	{
		// private constructor
	}
	
	
}
