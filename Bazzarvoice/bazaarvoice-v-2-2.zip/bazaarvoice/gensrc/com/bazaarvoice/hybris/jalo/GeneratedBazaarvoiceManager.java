/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 6, 2018 12:33:54 PM                     ---
 * ----------------------------------------------------------------
 */
package com.bazaarvoice.hybris.jalo;

import com.bazaarvoice.hybris.constants.BazaarvoiceConstants;
import com.bazaarvoice.hybris.jalo.BazaarvoiceConfig;
import com.bazaarvoice.hybris.jalo.BazaarvoiceProductFeedExportCronJob;
import de.hybris.platform.basecommerce.jalo.site.BaseSite;
import de.hybris.platform.cms2.jalo.site.CMSSite;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.C2LManager;
import de.hybris.platform.jalo.c2l.Language;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type <code>BazaarvoiceManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedBazaarvoiceManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("bvConfig", AttributeMode.INITIAL);
		tmp.put("bvLocale", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.cms2.jalo.site.CMSSite", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CMSSite.bvConfig</code> attribute.
	 * @return the bvConfig - BazaarVoice config object with required information for remote connection
	 */
	public BazaarvoiceConfig getBvConfig(final SessionContext ctx, final CMSSite item)
	{
		return (BazaarvoiceConfig)item.getProperty( ctx, BazaarvoiceConstants.Attributes.CMSSite.BVCONFIG);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CMSSite.bvConfig</code> attribute.
	 * @return the bvConfig - BazaarVoice config object with required information for remote connection
	 */
	public BazaarvoiceConfig getBvConfig(final CMSSite item)
	{
		return getBvConfig( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CMSSite.bvConfig</code> attribute. 
	 * @param value the bvConfig - BazaarVoice config object with required information for remote connection
	 */
	public void setBvConfig(final SessionContext ctx, final CMSSite item, final BazaarvoiceConfig value)
	{
		item.setProperty(ctx, BazaarvoiceConstants.Attributes.CMSSite.BVCONFIG,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CMSSite.bvConfig</code> attribute. 
	 * @param value the bvConfig - BazaarVoice config object with required information for remote connection
	 */
	public void setBvConfig(final CMSSite item, final BazaarvoiceConfig value)
	{
		setBvConfig( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CMSSite.bvLocale</code> attribute.
	 * @return the bvLocale
	 */
	public String getBvLocale(final SessionContext ctx, final CMSSite item)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedCMSSite.getBvLocale requires a session language", 0 );
		}
		return (String)item.getLocalizedProperty( ctx, BazaarvoiceConstants.Attributes.CMSSite.BVLOCALE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CMSSite.bvLocale</code> attribute.
	 * @return the bvLocale
	 */
	public String getBvLocale(final CMSSite item)
	{
		return getBvLocale( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CMSSite.bvLocale</code> attribute. 
	 * @return the localized bvLocale
	 */
	public Map<Language,String> getAllBvLocale(final SessionContext ctx, final CMSSite item)
	{
		return (Map<Language,String>)item.getAllLocalizedProperties(ctx,BazaarvoiceConstants.Attributes.CMSSite.BVLOCALE,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CMSSite.bvLocale</code> attribute. 
	 * @return the localized bvLocale
	 */
	public Map<Language,String> getAllBvLocale(final CMSSite item)
	{
		return getAllBvLocale( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CMSSite.bvLocale</code> attribute. 
	 * @param value the bvLocale
	 */
	public void setBvLocale(final SessionContext ctx, final CMSSite item, final String value)
	{
		if ( ctx == null) 
		{
			throw new JaloInvalidParameterException( "ctx is null", 0 );
		}
		if( ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedCMSSite.setBvLocale requires a session language", 0 );
		}
		item.setLocalizedProperty(ctx, BazaarvoiceConstants.Attributes.CMSSite.BVLOCALE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CMSSite.bvLocale</code> attribute. 
	 * @param value the bvLocale
	 */
	public void setBvLocale(final CMSSite item, final String value)
	{
		setBvLocale( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CMSSite.bvLocale</code> attribute. 
	 * @param value the bvLocale
	 */
	public void setAllBvLocale(final SessionContext ctx, final CMSSite item, final Map<Language,String> value)
	{
		item.setAllLocalizedProperties(ctx,BazaarvoiceConstants.Attributes.CMSSite.BVLOCALE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CMSSite.bvLocale</code> attribute. 
	 * @param value the bvLocale
	 */
	public void setAllBvLocale(final CMSSite item, final Map<Language,String> value)
	{
		setAllBvLocale( getSession().getSessionContext(), item, value );
	}
	
	public BazaarvoiceConfig createBazaarvoiceConfig(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BazaarvoiceConstants.TC.BAZAARVOICECONFIG );
			return (BazaarvoiceConfig)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating BazaarvoiceConfig : "+e.getMessage(), 0 );
		}
	}
	
	public BazaarvoiceConfig createBazaarvoiceConfig(final Map attributeValues)
	{
		return createBazaarvoiceConfig( getSession().getSessionContext(), attributeValues );
	}
	
	public BazaarvoiceProductFeedExportCronJob createBazaarvoiceProductFeedExportCronJob(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( BazaarvoiceConstants.TC.BAZAARVOICEPRODUCTFEEDEXPORTCRONJOB );
			return (BazaarvoiceProductFeedExportCronJob)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating BazaarvoiceProductFeedExportCronJob : "+e.getMessage(), 0 );
		}
	}
	
	public BazaarvoiceProductFeedExportCronJob createBazaarvoiceProductFeedExportCronJob(final Map attributeValues)
	{
		return createBazaarvoiceProductFeedExportCronJob( getSession().getSessionContext(), attributeValues );
	}
	
	@Override
	public String getName()
	{
		return BazaarvoiceConstants.EXTENSIONNAME;
	}
	
}
