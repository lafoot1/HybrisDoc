/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 6, 2018 12:33:54 PM                     ---
 * ----------------------------------------------------------------
 */
package com.bazaarvoice.hybris.jalo;

import com.bazaarvoice.hybris.constants.BazaarvoiceConstants;
import de.hybris.platform.cms2.jalo.site.CMSSite;
import de.hybris.platform.cronjob.jalo.CronJob;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.cronjob.jalo.CronJob BazaarvoiceProductFeedExportCronJob}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedBazaarvoiceProductFeedExportCronJob extends CronJob
{
	/** Qualifier of the <code>BazaarvoiceProductFeedExportCronJob.bazaarvoiceStorefront</code> attribute **/
	public static final String BAZAARVOICESTOREFRONT = "bazaarvoiceStorefront";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(CronJob.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(BAZAARVOICESTOREFRONT, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceProductFeedExportCronJob.bazaarvoiceStorefront</code> attribute.
	 * @return the bazaarvoiceStorefront - Bazaarvoice credential information
	 */
	public CMSSite getBazaarvoiceStorefront(final SessionContext ctx)
	{
		return (CMSSite)getProperty( ctx, BAZAARVOICESTOREFRONT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceProductFeedExportCronJob.bazaarvoiceStorefront</code> attribute.
	 * @return the bazaarvoiceStorefront - Bazaarvoice credential information
	 */
	public CMSSite getBazaarvoiceStorefront()
	{
		return getBazaarvoiceStorefront( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceProductFeedExportCronJob.bazaarvoiceStorefront</code> attribute. 
	 * @param value the bazaarvoiceStorefront - Bazaarvoice credential information
	 */
	public void setBazaarvoiceStorefront(final SessionContext ctx, final CMSSite value)
	{
		setProperty(ctx, BAZAARVOICESTOREFRONT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceProductFeedExportCronJob.bazaarvoiceStorefront</code> attribute. 
	 * @param value the bazaarvoiceStorefront - Bazaarvoice credential information
	 */
	public void setBazaarvoiceStorefront(final CMSSite value)
	{
		setBazaarvoiceStorefront( getSession().getSessionContext(), value );
	}
	
}
