/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 6, 2018 12:33:54 PM                     ---
 * ----------------------------------------------------------------
 */
package com.bazaarvoice.hybris.jalo;

import com.bazaarvoice.hybris.constants.BazaarvoiceConstants;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.jalo.GenericItem BazaarvoiceConfig}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedBazaarvoiceConfig extends GenericItem
{
	/** Qualifier of the <code>BazaarvoiceConfig.code</code> attribute **/
	public static final String CODE = "code";
	/** Qualifier of the <code>BazaarvoiceConfig.clientName</code> attribute **/
	public static final String CLIENTNAME = "clientName";
	/** Qualifier of the <code>BazaarvoiceConfig.ftpUserName</code> attribute **/
	public static final String FTPUSERNAME = "ftpUserName";
	/** Qualifier of the <code>BazaarvoiceConfig.ftpPassword</code> attribute **/
	public static final String FTPPASSWORD = "ftpPassword";
	/** Qualifier of the <code>BazaarvoiceConfig.zone</code> attribute **/
	public static final String ZONE = "zone";
	/** Qualifier of the <code>BazaarvoiceConfig.seoKey</code> attribute **/
	public static final String SEOKEY = "seoKey";
	/** Qualifier of the <code>BazaarvoiceConfig.ftpServer</code> attribute **/
	public static final String FTPSERVER = "ftpServer";
	/** Qualifier of the <code>BazaarvoiceConfig.environment</code> attribute **/
	public static final String ENVIRONMENT = "environment";
	/** Qualifier of the <code>BazaarvoiceConfig.upcMethodName</code> attribute **/
	public static final String UPCMETHODNAME = "upcMethodName";
	/** Qualifier of the <code>BazaarvoiceConfig.showReviewsScript</code> attribute **/
	public static final String SHOWREVIEWSSCRIPT = "showReviewsScript";
	/** Qualifier of the <code>BazaarvoiceConfig.showQuestionsScript</code> attribute **/
	public static final String SHOWQUESTIONSSCRIPT = "showQuestionsScript";
	/** Qualifier of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute **/
	public static final String ISFAMILIESENABLED = "isFamiliesEnabled";
	/** Qualifier of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute **/
	public static final String LICENSEACCEPTED = "licenseAccepted";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(CODE, AttributeMode.INITIAL);
		tmp.put(CLIENTNAME, AttributeMode.INITIAL);
		tmp.put(FTPUSERNAME, AttributeMode.INITIAL);
		tmp.put(FTPPASSWORD, AttributeMode.INITIAL);
		tmp.put(ZONE, AttributeMode.INITIAL);
		tmp.put(SEOKEY, AttributeMode.INITIAL);
		tmp.put(FTPSERVER, AttributeMode.INITIAL);
		tmp.put(ENVIRONMENT, AttributeMode.INITIAL);
		tmp.put(UPCMETHODNAME, AttributeMode.INITIAL);
		tmp.put(SHOWREVIEWSSCRIPT, AttributeMode.INITIAL);
		tmp.put(SHOWQUESTIONSSCRIPT, AttributeMode.INITIAL);
		tmp.put(ISFAMILIESENABLED, AttributeMode.INITIAL);
		tmp.put(LICENSEACCEPTED, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.clientName</code> attribute.
	 * @return the clientName - Name of client
	 */
	public String getClientName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, CLIENTNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.clientName</code> attribute.
	 * @return the clientName - Name of client
	 */
	public String getClientName()
	{
		return getClientName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.clientName</code> attribute. 
	 * @param value the clientName - Name of client
	 */
	public void setClientName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, CLIENTNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.clientName</code> attribute. 
	 * @param value the clientName - Name of client
	 */
	public void setClientName(final String value)
	{
		setClientName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.code</code> attribute.
	 * @return the code - unique code that identifies the Bazaarvoice
	 * 							configuration
	 */
	public String getCode(final SessionContext ctx)
	{
		return (String)getProperty( ctx, CODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.code</code> attribute.
	 * @return the code - unique code that identifies the Bazaarvoice
	 * 							configuration
	 */
	public String getCode()
	{
		return getCode( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.code</code> attribute. 
	 * @param value the code - unique code that identifies the Bazaarvoice
	 * 							configuration
	 */
	protected void setCode(final SessionContext ctx, final String value)
	{
		if ( ctx == null) 
		{
			throw new JaloInvalidParameterException( "ctx is null", 0 );
		}
		// initial-only attribute: make sure this attribute can be set during item creation only
		if ( ctx.getAttribute( "core.types.creation.initial") != Boolean.TRUE )
		{
			throw new JaloInvalidParameterException( "attribute '"+CODE+"' is not changeable", 0 );
		}
		setProperty(ctx, CODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.code</code> attribute. 
	 * @param value the code - unique code that identifies the Bazaarvoice
	 * 							configuration
	 */
	protected void setCode(final String value)
	{
		setCode( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.environment</code> attribute.
	 * @return the environment - Production or Staging Environment button
	 */
	public EnumerationValue getEnvironment(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, ENVIRONMENT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.environment</code> attribute.
	 * @return the environment - Production or Staging Environment button
	 */
	public EnumerationValue getEnvironment()
	{
		return getEnvironment( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.environment</code> attribute. 
	 * @param value the environment - Production or Staging Environment button
	 */
	public void setEnvironment(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, ENVIRONMENT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.environment</code> attribute. 
	 * @param value the environment - Production or Staging Environment button
	 */
	public void setEnvironment(final EnumerationValue value)
	{
		setEnvironment( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.ftpPassword</code> attribute.
	 * @return the ftpPassword - FTP password
	 */
	public String getFtpPassword(final SessionContext ctx)
	{
		return (String)getProperty( ctx, FTPPASSWORD);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.ftpPassword</code> attribute.
	 * @return the ftpPassword - FTP password
	 */
	public String getFtpPassword()
	{
		return getFtpPassword( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.ftpPassword</code> attribute. 
	 * @param value the ftpPassword - FTP password
	 */
	public void setFtpPassword(final SessionContext ctx, final String value)
	{
		setProperty(ctx, FTPPASSWORD,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.ftpPassword</code> attribute. 
	 * @param value the ftpPassword - FTP password
	 */
	public void setFtpPassword(final String value)
	{
		setFtpPassword( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.ftpServer</code> attribute.
	 * @return the ftpServer - The address to connect to the SFTP server
	 */
	public String getFtpServer(final SessionContext ctx)
	{
		return (String)getProperty( ctx, FTPSERVER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.ftpServer</code> attribute.
	 * @return the ftpServer - The address to connect to the SFTP server
	 */
	public String getFtpServer()
	{
		return getFtpServer( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.ftpServer</code> attribute. 
	 * @param value the ftpServer - The address to connect to the SFTP server
	 */
	public void setFtpServer(final SessionContext ctx, final String value)
	{
		setProperty(ctx, FTPSERVER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.ftpServer</code> attribute. 
	 * @param value the ftpServer - The address to connect to the SFTP server
	 */
	public void setFtpServer(final String value)
	{
		setFtpServer( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.ftpUserName</code> attribute.
	 * @return the ftpUserName - FTP user name
	 */
	public String getFtpUserName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, FTPUSERNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.ftpUserName</code> attribute.
	 * @return the ftpUserName - FTP user name
	 */
	public String getFtpUserName()
	{
		return getFtpUserName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.ftpUserName</code> attribute. 
	 * @param value the ftpUserName - FTP user name
	 */
	public void setFtpUserName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, FTPUSERNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.ftpUserName</code> attribute. 
	 * @param value the ftpUserName - FTP user name
	 */
	public void setFtpUserName(final String value)
	{
		setFtpUserName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute.
	 * @return the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public Boolean isIsFamiliesEnabled(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, ISFAMILIESENABLED);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute.
	 * @return the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public Boolean isIsFamiliesEnabled()
	{
		return isIsFamiliesEnabled( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute. 
	 * @return the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public boolean isIsFamiliesEnabledAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isIsFamiliesEnabled( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute. 
	 * @return the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public boolean isIsFamiliesEnabledAsPrimitive()
	{
		return isIsFamiliesEnabledAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute. 
	 * @param value the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public void setIsFamiliesEnabled(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, ISFAMILIESENABLED,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute. 
	 * @param value the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public void setIsFamiliesEnabled(final Boolean value)
	{
		setIsFamiliesEnabled( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute. 
	 * @param value the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public void setIsFamiliesEnabled(final SessionContext ctx, final boolean value)
	{
		setIsFamiliesEnabled( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.isFamiliesEnabled</code> attribute. 
	 * @param value the isFamiliesEnabled - Code snippet that will be executed in the show questions script
	 */
	public void setIsFamiliesEnabled(final boolean value)
	{
		setIsFamiliesEnabled( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute.
	 * @return the licenseAccepted - Is licence agreement accepted
	 */
	public Boolean isLicenseAccepted(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, LICENSEACCEPTED);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute.
	 * @return the licenseAccepted - Is licence agreement accepted
	 */
	public Boolean isLicenseAccepted()
	{
		return isLicenseAccepted( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute. 
	 * @return the licenseAccepted - Is licence agreement accepted
	 */
	public boolean isLicenseAcceptedAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isLicenseAccepted( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute. 
	 * @return the licenseAccepted - Is licence agreement accepted
	 */
	public boolean isLicenseAcceptedAsPrimitive()
	{
		return isLicenseAcceptedAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute. 
	 * @param value the licenseAccepted - Is licence agreement accepted
	 */
	public void setLicenseAccepted(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, LICENSEACCEPTED,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute. 
	 * @param value the licenseAccepted - Is licence agreement accepted
	 */
	public void setLicenseAccepted(final Boolean value)
	{
		setLicenseAccepted( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute. 
	 * @param value the licenseAccepted - Is licence agreement accepted
	 */
	public void setLicenseAccepted(final SessionContext ctx, final boolean value)
	{
		setLicenseAccepted( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.licenseAccepted</code> attribute. 
	 * @param value the licenseAccepted - Is licence agreement accepted
	 */
	public void setLicenseAccepted(final boolean value)
	{
		setLicenseAccepted( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.seoKey</code> attribute.
	 * @return the seoKey - Cloud SEO Key
	 */
	public String getSeoKey(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SEOKEY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.seoKey</code> attribute.
	 * @return the seoKey - Cloud SEO Key
	 */
	public String getSeoKey()
	{
		return getSeoKey( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.seoKey</code> attribute. 
	 * @param value the seoKey - Cloud SEO Key
	 */
	public void setSeoKey(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SEOKEY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.seoKey</code> attribute. 
	 * @param value the seoKey - Cloud SEO Key
	 */
	public void setSeoKey(final String value)
	{
		setSeoKey( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.showQuestionsScript</code> attribute.
	 * @return the showQuestionsScript - Code snippet that will be executed in the show questions script
	 */
	public String getShowQuestionsScript(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SHOWQUESTIONSSCRIPT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.showQuestionsScript</code> attribute.
	 * @return the showQuestionsScript - Code snippet that will be executed in the show questions script
	 */
	public String getShowQuestionsScript()
	{
		return getShowQuestionsScript( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.showQuestionsScript</code> attribute. 
	 * @param value the showQuestionsScript - Code snippet that will be executed in the show questions script
	 */
	public void setShowQuestionsScript(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SHOWQUESTIONSSCRIPT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.showQuestionsScript</code> attribute. 
	 * @param value the showQuestionsScript - Code snippet that will be executed in the show questions script
	 */
	public void setShowQuestionsScript(final String value)
	{
		setShowQuestionsScript( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.showReviewsScript</code> attribute.
	 * @return the showReviewsScript - Code snippet that will be executed in the show reviews script
	 */
	public String getShowReviewsScript(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SHOWREVIEWSSCRIPT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.showReviewsScript</code> attribute.
	 * @return the showReviewsScript - Code snippet that will be executed in the show reviews script
	 */
	public String getShowReviewsScript()
	{
		return getShowReviewsScript( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.showReviewsScript</code> attribute. 
	 * @param value the showReviewsScript - Code snippet that will be executed in the show reviews script
	 */
	public void setShowReviewsScript(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SHOWREVIEWSSCRIPT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.showReviewsScript</code> attribute. 
	 * @param value the showReviewsScript - Code snippet that will be executed in the show reviews script
	 */
	public void setShowReviewsScript(final String value)
	{
		setShowReviewsScript( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.upcMethodName</code> attribute.
	 * @return the upcMethodName - The name of your getter method for upc from ProductModel
	 */
	public String getUpcMethodName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, UPCMETHODNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.upcMethodName</code> attribute.
	 * @return the upcMethodName - The name of your getter method for upc from ProductModel
	 */
	public String getUpcMethodName()
	{
		return getUpcMethodName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.upcMethodName</code> attribute. 
	 * @param value the upcMethodName - The name of your getter method for upc from ProductModel
	 */
	public void setUpcMethodName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, UPCMETHODNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.upcMethodName</code> attribute. 
	 * @param value the upcMethodName - The name of your getter method for upc from ProductModel
	 */
	public void setUpcMethodName(final String value)
	{
		setUpcMethodName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.zone</code> attribute.
	 * @return the zone - Deployment Zone Name
	 */
	public String getZone(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ZONE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BazaarvoiceConfig.zone</code> attribute.
	 * @return the zone - Deployment Zone Name
	 */
	public String getZone()
	{
		return getZone( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.zone</code> attribute. 
	 * @param value the zone - Deployment Zone Name
	 */
	public void setZone(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ZONE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BazaarvoiceConfig.zone</code> attribute. 
	 * @param value the zone - Deployment Zone Name
	 */
	public void setZone(final String value)
	{
		setZone( getSession().getSessionContext(), value );
	}
	
}
