/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 6, 2018 12:33:54 PM                     ---
 * ----------------------------------------------------------------
 */
package com.hybris.bvbackoffice.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedBvbackofficeConstants
{
	public static final String EXTENSIONNAME = "bvbackoffice";
	
	protected GeneratedBvbackofficeConstants()
	{
		// private constructor
	}
	
	
}
